package com.example.springbootjpapostgresql.repository;

import com.example.springbootjpapostgresql.model.Tutorial;
import com.example.springbootjpapostgresql.repository.TutorialRepository;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import com.example.springbootjpapostgresql.model.Tutorial;

public interface TutorialRepository extends JpaRepository<Tutorial, Long> {
    List<Tutorial> findByPublished(boolean published);

    List<Tutorial> findByTitleContaining(String title);
}
