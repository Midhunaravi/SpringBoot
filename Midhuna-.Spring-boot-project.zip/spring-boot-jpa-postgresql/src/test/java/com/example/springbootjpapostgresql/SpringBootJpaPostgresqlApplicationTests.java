package com.example.springbootjpapostgresql;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootJpaPostgresqlApplicationTests {

	@Test
	void contextLoads() {
	}

}
